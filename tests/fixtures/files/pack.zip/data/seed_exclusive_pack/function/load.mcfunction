say seed exclusive pack loaded
